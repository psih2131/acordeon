$(function() {

	  //FAQ open/close
	  $('.faqBox_header').on('click', function () {
        var updateClass = function () {
            if ($(this).is(':visible')) {
                $(this).closest('.faqBox').find('.faqBox_header').addClass('openFaq');
                $(this).closest('.faqBox').addClass("active");
            } else {
                $(this).closest('.faqBox').find('.faqBox_header').removeClass('openFaq');
                $(this).closest('.faqBox').removeClass('active');
            }
        };
        $('.faqBox_body').not($(this).next()).slideUp(500, updateClass);
        $(this).addClass('openFaq').next().slideToggle(500, updateClass);
    });


		$(".play-btn").click(function(){
			$(this).parent().find("video")[0].play();
			$(this).parent().find("video")[0].controls = true;
			$(this).fadeIn();
		})


		$(".tab").on("click", function (e) {
			e.preventDefault();
			$(this)
			  .addClass("active")
			  .siblings()
			  .removeClass("active")
			  .closest(".started__line")
			  .find(".started__box")
			  .removeClass("active")
			  .eq($(this).index())
			  .addClass("active");

			  $(".started__box").each(function(){
				$(this).not("active").find("video")[0].pause();
				$(this).not("active").find("video")[0].currentTime = 0;
			  })
		  });
		  


		  $(".team__slider").slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 700,
			slidesToShow: 4,
			slidesToScroll: 1,
			prevArrow: $('.prev__team'),
			nextArrow: $('.next__team'),
			autoplay: true,
			responsive: [{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3
				}
			},{
				breakpoint: 768,
				settings: {
					slidesToShow: 2
				}
			},{
				breakpoint: 500,
				settings: {
					slidesToShow: 1
				}
			}
			]
		  })


		  $(".blog__slider").slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 700,
			slidesToShow: 1,
			slidesToScroll: 1,
			prevArrow: $('.prev__blog'),
			nextArrow: $('.next__blog'),
			autoplay: true,
		  })

		  $(".partners__slider").slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 700,
			slidesToShow: 3,
			slidesToScroll: 1,
			prevArrow: $('.prev__partners'),
			nextArrow: $('.next__partners'),
			autoplay: true,
			responsive: [{
				breakpoint: 768,
				settings: {
					slidesToShow: 2
				}
			},{
				breakpoint: 500,
				settings: {
					slidesToShow: 1
				}
			}
			]
		  })

		  $(".whyuse__slider").slick({
			dots: false,
			arrows: true,
			infinite: true,
			speed: 700,
			slidesToShow: 4,
			slidesToScroll: 1,
			prevArrow: $('.prev__whyuse'),
			nextArrow: $('.next__whyuse'),
			autoplay: true,
			responsive: [{
				breakpoint: 1024,
				settings: {
					slidesToShow: 3
				}
			},{
				breakpoint: 768,
				settings: {
					slidesToShow: 2
				}
			},{
				breakpoint: 500,
				settings: {
					slidesToShow: 1
				}
			}
			]
		  })

		  $(".current-lang").click(function(e){
			  e.preventDefault();
			  $(this).toggleClass("active");
			  $(".dropdown-lang").fadeIn();
		  })

		  $(".language").each(function(){
			$(this).click(function(){
				let srcImg = $(this).find("img").attr("src");
				let spanText = $(this).find("span").text();
				$(".current-lang").find("img").attr("src", `${srcImg}`);
				$(".current-lang").find("span").text(`${spanText}`);
				$(".dropdown-lang").fadeOut();
				$(".current-lang").removeClass("active");
			})	
		  })

		  $(".current-currency").click(function(e){
			e.preventDefault();
			$(this).toggleClass("active");
			$(".dropdown-currency").fadeIn();
		})


		  $(".currency").each(function(){
			$(this).click(function(e){
				e.preventDefault();
				let srcImg = $(this).find("img").attr("src");
				let spanShort = $(this).find(".short").text();
				let spanLong = $(this).find(".long").text();
				$(".current-currency").find("img").attr("src", `${srcImg}`);
				$(".current-currency").find(".short").text(`${spanShort}`);
				$(".current-currency").find(".long").text(`${spanLong}`);
				$(".dropdown-currency").fadeOut();
				$(".current-currency").removeClass("active");
				$(`input[name="cryptoType"]`).val(`${spanShort}`);
			})	
		  })


		  $(".current-amount").click(function(e){
			e.preventDefault();
			e.stopPropagation();
			$(this).toggleClass("active");
			$(".dropdown-amount").fadeIn();
		})

		$(".amount").each(function(){
		  $(this).click(function(e){
			  e.preventDefault();
			  e.stopPropagation();
			  let value = $(this).find(".value").text();
			  let short = $(this).find(".short").text();
			  $(".current-amount").find(".value").text(`${value}`);
			  $(".current-amount").find(".short").text(`${short}`);
			  $(".dropdown-amount").fadeOut();
			  $(".current-amount").removeClass("active");
		  })	
		})

		$(".header__mobile .close-btn").click(function (e){
			e.preventDefault();
			$(".header__mobile").removeClass("active");
			$("html").removeClass("static")
		})
		$(".burger-btn").click(function (e){
			e.preventDefault();
			$(".header__mobile").addClass("active");
			$("html").addClass("static")
		})

		let tableSlider = $(".table__slider")
		let standartSlider = $(".standart__line")
		  	  
		
		$(document).ready(function(){
			if($(window).width() < 1024){
			 initializeSlick()
			}
		  
		  
			$(window).on('resize', function(){
			  if($(window).width() > 1024){
				$(".table__slider.slick-initialized").slick("unslick");
			  } else if(!$('.table__slider').hasClass('slick-initialized')) {
				initializeSlick()
			  }
			});
		  
		  
			  function initializeSlick() {
				tableSlider.slick({
					infinite: true,
					prevArrow: false,
					nextArrow: false,
					speed: 700,
					slidesToShow: 2,
					slidesToScroll:1,
					autoplay:false,
					dots: true,
					autoplay: true,
					responsive: [{
						breakpoint: 670,
						settings: {
							slidesToShow: 1
						}
					}]
				  });
				}
			});


			$(document).ready(function(){
				if($(window).width() < 768){
					initializeStandartSlick()
				}
			  
			  
				$(window).on('resize', function(){
				  if($(window).width() > 768){
					$(".standart__line.slick-initialized").slick("unslick");
				  } else if(!$('.standart__line').hasClass('slick-initialized')) {
					initializeStandartSlick()
				  }
				});
				  function initializeStandartSlick() {
					standartSlider.slick({
						infinite: true,
						prevArrow: false,
						nextArrow: false,
						speed: 700,
						slidesToShow: 2,
						slidesToScroll:1,
						autoplay:false,
						dots: false,
						autoplay: true,
						responsive: [{
							breakpoint: 600,
							settings: {
								slidesToShow: 1
							}
						}]
					  });
					}
				});

		let createSlider = $(".create__in")
				
				$(document).ready(function(){
					if($(window).width() < 1024){
						initializeCreateSliderSlick()
					}
				  
				  
					$(window).on('resize', function(){
					  if($(window).width() > 1024){
						$(".create__in.slick-initialized").slick("unslick");
					  } else if(!$('.standart__line').hasClass('slick-initialized')) {
						initializeCreateSliderSlick()
					  }
					});
				  
				
					  function initializeCreateSliderSlick() {
						
						createSlider.slick({
							infinite: true,
							prevArrow: false,
							nextArrow: false,
							speed: 700,
							slidesToShow: 4,
							slidesToScroll:1,
							autoplay:false,
							dots: false,
							autoplay: true,
							responsive: [{
								breakpoint: 1024,
								settings: {
									slidesToShow: 3
								}
							},{
								breakpoint: 768,
								settings: {
									slidesToShow: 2
								}
							},{
								breakpoint: 500,
								settings: {
									slidesToShow: 1
								}
							}
							]
						  });
						}
					});

			$(".btn-see").click(function(){
				$(".allcrypto__line").toggleClass("active");
			})

			$(".read-more-btn").click(function(e){
				e.preventDefault();
				$(this).parent().prev().toggleClass("open");
				$(this).toggleClass("open")
				if($(this).hasClass("open")){
					$(this).find("span").text("Read less")
				} else{
					$(this).find("span").text("Read more")
				}
			})
});



